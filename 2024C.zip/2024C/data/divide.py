from datetime import *

import matplotlib.pyplot as plt  # 画图用
import numpy as np
import pandas as pd
import matplotlib
import openpyxl

data = pd.read_csv(r'C:\Users\钱天豪\Desktop\c2.csv')
wb = openpyxl.load_workbook(r'C:\Users\钱天豪\Desktop\qwer.xlsx')
wb2 = openpyxl.load_workbook(r'C:\Users\钱天豪\Desktop\qwer2.xlsx')

df = pd.DataFrame(data)

elapsetime = 0
p1ace = 0
p2ace = 0
p1double = 0
p2double = 0
p1mistake = 0
p2mistake = 0
p1firstshot = 0
p1secondshot = 0
p1firstshotplus = 0
p1secondshotplus = 0
p2firstshot = 0
p2secondshot = 0
p2firstshotplus = 0
p2secondshotplus = 0
p1winner = 0
p2winner = 0
p1netpt = 0
p2netpt = 0
p1netptwin = 0
p2netptwin = 0
p1breakpt = 0
p2breakpt = 0
p1breakptwin = 0
p2breakptwin = 0
p1score = 0
p2score = 0
p1distance = 0
p2distance = 0
rallycount = 0
p1breaktime = 0
p2breaktime = 0
pointnum = 0
p1point = 0
p2point = 0
temp1 = []
temp2 = []
total1 = []
total2 = []
point = 1

for i in range(len(df)):
    if i != 0 and data.loc[i, "judge"] != data.loc[i - 1, "judge"]:
        p1ace = 0
        p2ace = 0
        p1double = 0
        p2double = 0
        p1mistake = 0
        p2mistake = 0
        p1firstshot = 0
        p1secondshot = 0
        p1firstshotplus = 0
        p1secondshotplus = 0
        p2firstshot = 0
        p2secondshot = 0
        p2firstshotplus = 0
        p2secondshotplus = 0
        p1winner = 0
        p2winner = 0
        p1netpt = 0
        p2netpt = 0
        p1netptwin = 0
        p2netptwin = 0
        p1breakpt = 0
        p2breakpt = 0
        p1breakptwin = 0
        p2breakptwin = 0
        p1score = 0
        p2score = 0
        p1distance = 0
        p2distance = 0
        rallycount = 0
        p1breaktime = 0
        p2breaktime = 0
        pointnum = 0
    temp1.append(data.loc[i, "elapsed_time"])
    temp1.append(data.loc[i, "set_no"])
    temp1.append(data.loc[i, "game_no"])
    temp1.append(data.loc[i, "point_no"])
    temp1.append(p1ace)
    temp1.append(p1double)
    temp1.append(p1mistake)
    if p1firstshot == 0:
        temp1.append(0)
    else:
        temp1.append(p1firstshotplus / p1firstshot)
    if p1secondshot == 0:
        temp1.append(0)
    else:
        temp1.append(p1secondshotplus / p1secondshot)
    temp1.append(p1winner)
    if p1netpt == 0:
        temp1.append(0)
    else:
        temp1.append(p1netptwin / p1netpt)
    temp1.append(p1breaktime)
    temp1.append(p1distance)
    temp1.append(p2distance)
    temp1.append(p1point)
    total1.append(temp1.copy())
    temp1.clear()

    temp1.append(data.loc[i, "elapsed_time"])
    temp1.append(data.loc[i, "set_no"])
    temp1.append(data.loc[i, "game_no"])
    temp1.append(data.loc[i, "point_no"])
    temp1.append(p2ace)
    temp1.append(p2double)
    temp1.append(p2mistake)
    if p2firstshot == 0:
        temp1.append(0)
    else:
        temp1.append(p2firstshotplus / p2firstshot)
    if p2secondshot == 0:
        temp1.append(0)
    else:
        temp1.append(p2secondshotplus / p2secondshot)
    temp1.append(p2winner)
    if p2netpt == 0:
        temp1.append(0)
    else:
        temp1.append(p2netptwin / p2netpt)
    temp1.append(p2breaktime)
    temp1.append(p2distance)
    temp1.append(p1distance)
    temp1.append(p2point)
    total2.append(temp1.copy())
    temp1.clear()

    p1distance = 0
    p2distance = 0
    p1ace = p1ace + data.loc[i, "p1_ace"]
    p2ace = p2ace + data.loc[i, "p2_ace"]
    p1winner = p1winner + data.loc[i, "p1_winner"]
    p2winner = p2winner + data.loc[i, "p2_winner"]
    p1double = p1double + data.loc[i, "p1_double_fault"]
    p2double = p2double + data.loc[i, "p2_double_fault"]
    p1mistake = p1mistake + data.loc[i, "p1_unf_err"]
    p2mistake = p2mistake + data.loc[i, "p2_unf_err"]
    p1netpt = p1netpt + data.loc[i, "p1_net_pt"]
    p2netpt = p2netpt + data.loc[i, "p2_net_pt"]
    p1breakpt = p1breakpt + data.loc[i, "p1_break_pt"]
    p2breakpt = p2breakpt + data.loc[i, "p2_break_pt"]
    p1netptwin = p1netptwin + data.loc[i, "p1_net_pt_won"]
    p2netptwin = p2netptwin + data.loc[i, "p2_net_pt_won"]
    p1breakptwin = p1breakptwin + data.loc[i, "p1_break_pt_won"]
    p2breakptwin = p2breakptwin + data.loc[i, "p2_break_pt_won"]
    p1distance = p1distance + data.loc[i, "p1_distance_run"]
    p2distance = p2distance + data.loc[i, "p2_distance_run"]
    if data.loc[i, "p1_points_won"] + data.loc[i, "p2_points_won"] == 1:
        p1point = data.loc[i, "p1_points_won"]
        p2point = data.loc[i, "p2_points_won"]
    elif data.loc[i, "p1_points_won"] - data.loc[i - 1, "p1_points_won"] == 1:
        p1point = p1point + 1
        p2point = 0
    elif data.loc[i, "p2_points_won"] - data.loc[i - 1, "p2_points_won"] == 1:
        p2point = p2point + 1
        p1point = 0
    # 考虑serve
    if data.loc[i, "server"] == 1:
        if i != 0 and data.loc[i, "serve_no"] == 1:
            p1firstshot = p1firstshot + 1
            if data.loc[i, "p1_score"] != data.loc[i - 1, "p1_score"]:
                p1firstshotplus = p1firstshotplus + 1
        else:
            p1secondshot = p1secondshot + 1
            if i != 0 and data.loc[i, "p1_score"] != data.loc[i - 1, "p1_score"]:
                p1secondshotplus = p1secondshotplus + 1
    else:
        if data.loc[i, "serve_no"] == 1:
            p2firstshot = p2firstshot + 1
            if i != 0 and data.loc[i, "p2_score"] != data.loc[i - 1, "p2_score"]:
                p2firstshotplus = p2firstshotplus + 1
        else:
            p2secondshot = p2secondshot + 1
            if i != 0 and data.loc[i, "p2_score"] != data.loc[i - 1, "p2_score"]:
                p2secondshotplus = p2secondshotplus + 1
    if data.loc[i, "point_victor"] * data.loc[i, "server"] == 2:
        if data.loc[i, "point_victor"] == 1:
            p1breaktime = p1breaktime + 1
        else:
            p2breaktime = p2breaktime + 1

ws = wb['Sheet1']
ws2 = wb2['Sheet1']
ws.append(["player1", "set_no", "game_no", "point_no", "Aces", "Double Faults", "Unforced Errors", "First Serve",
           "Second Serve", "Winners", "Net Play", "Break Points Won","S1","S2","Contiunous"])
ws2.append(["player1", "set_no", "game_no", "point_no", "Aces", "Double Faults", "Unforced Errors", "First Serve",
            "Second Serve", "Winners", "Net Play", "Break Points Won","S1","S2","Contiunous"])
for i in total1:
    ws.append(i)
for i in total2:
    ws2.append(i)
wb.save(r'C:\Users\钱天豪\Desktop\qwer.xlsx')
wb2.save(r'C:\Users\钱天豪\Desktop\qwer2.xlsx')
