import xlrd
import numpy as np
import pandas as pd
import openpyxl
# data preprocessing
data = pd.read_excel(r'C:\Users\钱天豪\Desktop\data.xlsx',sheet_name='Data')

statelist=['KY', 'OH', 'PA', 'VA', 'WV']
shoppinglist2010 = []
shoppinglist2011 = []
shoppinglist2012 = []
shoppinglist2013 = []
shoppinglist2014 = []
shoppinglist2015 = []
shoppinglist2016 = []
shoppinglist2017 = []
temp = []
data.groupby('YYYY')
for state in statelist:
    datatemp = data[data.State == state]
    for i in range(2010,2018):
        data2 = datatemp[datatemp.YYYY == i]
        for county in data.FIPS_County.unique():
            data1 = data2[data2.FIPS_County == county].copy()
            temp = []
            for num in data1.number.unique():
                temp.append(str(num))
            if temp == []:
                continue
            if state=='KY':
                temp.append('KY')
            if state=='OH':
                temp.append('OH')
            if state=='PA':
                temp.append('PA')
            if state=='WV':
                temp.append('WV')
            if state=='VA':
                temp.append('VA')
            if i == 2010:
                shoppinglist2010.append(temp.copy())
            if i == 2011:
                shoppinglist2011.append(temp.copy())
            if i == 2012:
                shoppinglist2012.append(temp.copy())
            if i == 2013:
                shoppinglist2013.append(temp.copy())
            if i == 2014:
                shoppinglist2014.append(temp.copy())
            if i == 2015:
                shoppinglist2015.append(temp.copy())
            if i == 2016:
                shoppinglist2016.append(temp.copy())
            if i == 2017:
                shoppinglist2017.append(temp.copy())


from apyori import apriori
result2010 = list(apriori(transactions=shoppinglist2017, min_spport=0,min_confidence=0,min_lift=0))
result2010a = []
key=0
for result2 in result2010:
    if 'WV' in result2:
        print(result2)
        result2010a.append(str(result2))
import os
with open('testextra2017.txt', 'a') as file0:
    for i in result2010a:
        file0.write(i)
        file0.write(os.linesep)
        file0.write(os.linesep)
