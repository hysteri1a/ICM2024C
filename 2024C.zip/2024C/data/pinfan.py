import os

import xlrd
import numpy as np
import pandas as pd
import openpyxl
from apyori import apriori

total = []


# data preprocessing
def extract(path):
    data = pd.read_excel(path)
    temp = []
    for i in range(1, len(data)):
        if data.loc[i, "Contiunous"] == 1:
            if data.loc[i, "Aces"] - data.loc[i - 1, "Aces"] >= 1:
                temp.append("Aces")
            if data.loc[i, "Double Faults"] - data.loc[i - 1, "Double Faults"] >= 1:
                temp.append("Double Faults")
            if data.loc[i, "Unforced Errors"] - data.loc[i - 1, "Unforced Errors"] >= 1:
                temp.append("Unforced Errors")
            if data.loc[i, "First Serve"] > data.loc[i - 1, "First Serve"]:
                temp.append("First Serve")
            if data.loc[i, "Second Serve"] > data.loc[i - 1, "Second Serve"]:
                temp.append("Second Serve")
            if data.loc[i, "Winners"] - data.loc[i - 1, "Winners"] >= 1:
                temp.append("Winners")
            if data.loc[i, "Net Play"] - data.loc[i - 1, "Net Play"] >= 1:
                temp.append("Net Play")
            if data.loc[i, "Break Points Won"] - data.loc[i - 1, "Break Points Won"] >= 1:
                temp.append("Break Points Won")
            if data.loc[i, "S1"] > data.loc[i - 1, "S1"]:
                temp.append("S1")
            temp.append('swing')
        else:
            if data.loc[i, "Aces"] - data.loc[i - 1, "Aces"] >= 1:
                temp.append("Aces")
            if data.loc[i, "Double Faults"] - data.loc[i - 1, "Double Faults"] >= 1:
                temp.append("Double Faults")
            if data.loc[i, "Unforced Errors"] - data.loc[i - 1, "Unforced Errors"] >= 1:
                temp.append("Unforced Errors")
            if data.loc[i, "First Serve"] > data.loc[i - 1, "First Serve"]:
                temp.append("First Serve")
            if data.loc[i, "Second Serve"] > data.loc[i - 1, "Second Serve"]:
                temp.append("Second Serve")
            if data.loc[i, "Winners"] - data.loc[i - 1, "Winners"] >= 1:
                temp.append("Winners")
            if data.loc[i, "Net Play"] - data.loc[i - 1, "Net Play"] >= 1:
                temp.append("Net Play")
            if data.loc[i, "Break Points Won"] - data.loc[i - 1, "Break Points Won"] >= 1:
                temp.append("Break Points Won")
            if data.loc[i, "S1"] > data.loc[i - 1, "S1"] :
                temp.append("S1")
            temp.append('not swing')
        total.append(temp.copy())
        temp.clear()
    return total


total = extract(r"C:\Users\钱天豪\Desktop\对局\1\player1.xlsx")
total =extract(r"C:\Users\钱天豪\Desktop\对局\1\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\2\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\2\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\3\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\3\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\4\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\4\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\5\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\5\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\6\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\6\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\7\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\7\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\8\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\8\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\9\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\9\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\10\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\10\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\11\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\11\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\12\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\12\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\13\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\13\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\14\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\15\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\16\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\17\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\18\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\19\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\20\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\21\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\22\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\23\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\23\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\24\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\24\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\25\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\25\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\26\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\26\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\27\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\27\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\28\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\28\player2.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\29\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\30\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\31\player1.xlsx")
total = extract(r"C:\Users\钱天豪\Desktop\对局\31\player2.xlsx")


result = list(apriori(transactions=total, min_support=0.0001, min_confidence=0, min_lift=0))
with open('testextra2017.txt', 'a') as file0:
    for i in result:
        file0.write(str(i))
        file0.write(os.linesep)
        file0.write(os.linesep)

print(result)
