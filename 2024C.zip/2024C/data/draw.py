import pandas as pd
import openpyxl
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import matplotlib.ticker as ticker

data2 = pd.read_excel(r'C:\Users\钱天豪\Desktop\对局\1\Carlos Alcaraz.xlsx')
data1 = pd.read_excel(r'C:\Users\钱天豪\Desktop\对局\1\Nicolas Jarry.xlsx')

dot1 = data1.iloc[:, 4]
dot2 = data2.iloc[:, 4]
time = data2.iloc[:, 0]
date = []
sum1 = 0
sum2 = 0
dealtdata = []
minute = 1
timema = ""

format = "%H:%M:%S"
for i in time:
    date.append(datetime.strptime(str(i), format))
for i in range(len(dot1)):
    if i == 0:
        dealtdata.append(0.5)
        sum1 = sum1 + dot1[i]
        sum2 = sum2 + dot2[i]
        continue
    sum1 = sum1 + dot1[i]
    sum2 = sum2 + dot2[i]

    if sum1 > sum2:
        dealtdata.append(sum1 / (sum1 + sum2))
        if sum1 / (sum1 + sum2) < minute:
            minute = sum1 / (sum1 + sum2)
            timema = date[i]
    elif sum1 <= sum2:
        dealtdata.append(1 - sum2 / (sum1 + sum2))
        if 1 - sum2 / (sum1 + sum2) < minute:
            minute = sum1 / (sum1 + sum2)
            timema = date[i]
print(minute,timema)
fig, ax = plt.subplots()

ax.plot(date, dealtdata, label='Real-time Winning Percentage Curve')

xfmt = mdates.DateFormatter('%H:%M:%S')
date = pd.to_datetime(date)

plt.gca().yaxis.set_major_formatter(ticker.PercentFormatter(xmax=1, decimals=1))

pack1 = []
pack2 = []
date1 = []
date2 = []
for i in range(len(dot1)):
    if dealtdata[i] > 0.5:
        pack1.append(dealtdata[i])
        date1.append(date[i])
        ax.plot(date2, pack2, color='lightcoral', label='Real-time Winning Percentage Curve')
        date2.clear()
        pack2.clear()
        # ax.plot(date[i],dealtdata[i],color ='cornflowerblue',label='Real-time Winning Percentage Curve')
    else:
        pack2.append(dealtdata[i])
        date2.append(date[i])
        ax.plot(date1, pack1, color='cornflowerblue', label='Real-time Winning Percentage Curve')
        pack1.clear()
        date1.clear()
        # ax.plot(date[i],dealtdata[i],color ='lightcoral',label='Real-time Winning Percentage Curve')
plt.axhline(y=0.5, linestyle='--', color='y', alpha=0.5)
plt.axhline(y=0.25, linestyle='--', color='r', alpha=0.2)
plt.axhline(y=0.75, linestyle='--', color='r', alpha=0.2)
plt.title('Real-time Winning Percentage Curve')
plt.ylim(0, 1)
plt.yticks([0.5], alpha=0.1)
ax.axes.get_yaxis().set_visible(False)
ax.axes.get_xaxis().set_visible(False)
plt.annotate("Min", xy=(timema,minute), xytext=(timema,minute), arrowprops=dict(facecolor='black', shrink=0.02))

plt.gca().xaxis.set_major_formatter(xfmt)
ax.spines['bottom'].set_visible(False)
ax.spines['left'].set_color('y')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.show()
