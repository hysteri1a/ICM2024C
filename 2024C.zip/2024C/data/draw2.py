import pandas as pd
import numpy as np
import openpyxl
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import matplotlib.ticker as ticker

data2 = pd.read_excel(r'C:\Users\钱天豪\Desktop\对局\1\Carlos Alcaraz.xlsx')
data1 = pd.read_excel(r'C:\Users\钱天豪\Desktop\对局\1\Nicolas Jarry.xlsx')
x = np.arange(-6,6,0.1)
y1 = np.sin(x)
y2 = np.cos(x)
line1, = plt.plot(x, y1, color='lightcoral',linestyle='-', label="Carlos Alcaraz")
line2, = plt.plot(x, y2,color='cornflowerblue',linestyle='-', label="Nicolas Jarry")
plt.legend(loc="best", fontsize=6)
plt.show()
