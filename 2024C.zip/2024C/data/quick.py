import math

import pandas as pd
data = pd.read_csv(r"C:\Users\钱天豪\Desktop\result2.csv")

t1=[]
t2=[]
for i in range(len(data)):
    w1 = 0.20991536*data.loc[i,"p1_ace"] -0.0791275*data.loc[i,"p1_double_fault"] + 1.65536857*data.loc[i,"p1Firstserverate"] + 1.05755607*data.loc[i,"p1Secondrate"] + 0.26796471*data.loc[i,"p1_unf_err"] + 0.20123124*data.loc[i,"p1netrate"] - 0.20963877*data.loc[i,"p1breakrate"]
    w2 = 0.20991536 * data.loc[i, "p2_ace"] - 0.0791275 * data.loc[i, "p2_double_fault"] + 1.65536857 * data.loc[i, "p2Firstserverate"] + 1.05755607 * data.loc[i, "p2Secondrate"] + 0.26796471 * data.loc[i, "p2_unf_err"] + 0.20123124 * data.loc[i, "p2netrate"] - 0.20963877 * data.loc[i, "p2breakrate"]
    s1 = (34.375*data.loc[i,"p1acerate"] +33.3363949*data.loc[i,"p1breakrate"] + 11.0373253125*data.loc[i,"p1netrate"] + 78.75/(1+math.exp(0.10625*data.loc[i,"s1ave"])))*data.loc[i,"s2ave"]/data.loc[i,"s1ave"]
    s2 = (34.375*data.loc[i,"p2acerate"] +33.3363949*data.loc[i,"p2breakrate"] + 11.0373253125*data.loc[i,"p2netrate"] + 78.75/(1+math.exp(0.10625*data.loc[i,"s2ave"])))*data.loc[i,"s1ave"]/data.loc[i,"s2ave"]
    if w1*w2<0:
        temp = w1
        w1 = (w1-min(w1,w2))/(max(w1,w2)-min(w1,w2))
        w2 = (temp-min(temp,w2))/(max(temp,w2)-min(temp,w2))
    elif w1==0 and w2 ==0:
        w1 =0.5
        w2 =0.5
    elif w1>0:
        temp = w1
        w1 = w1/(w1+w2)
    elif w1<0:
        temp = w1
        w1 = w2/(w1+w2)
        w2 = temp/(temp+w2)
    t1.append(w1 * s1)
    t2.append(w2 * s2)
with open("temp.txt",'a') as f:
    for i in range(len(t1)):
        f.write(str(t1[i])+' ')
        f.write(str(t2[i]))
        f.write("\n")
f.close()
