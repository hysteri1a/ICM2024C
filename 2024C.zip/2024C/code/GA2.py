import math
import random

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# -*- coding: utf-8
from decimal import Decimal


def bTod(n, pre=4):
    '''
    把一个带小数的二进制数n转换成十进制
    小数点后面保留pre位小数
    '''
    string_number1 = str(n)  # number1 表示二进制数，number2表示十进制数
    decimal = 0  # 小数部分化成二进制后的值
    flag = False
    for i in string_number1:  # 判断是否含小数部分
        if i == '.':
            flag = True
            break
    if flag:  # 若二进制数含有小数部分
        string_integer, string_decimal = string_number1.split('.')  # 分离整数部分和小数部分
        for i in range(len(string_decimal)):
            decimal += 2 ** (-i - 1) * int(string_decimal[i])  # 小数部分化成二进制
        number2 = int(str(int(string_integer, 2))) + decimal
        return round(number2, pre)
    else:  # 若二进制数只有整数部分
        return int(string_number1, 2)  # 若只有整数部分 直接一行代码二进制转十进制 python还是骚
# ensure correct format
def exam(X):
    X1 = list(X)
    X1 = ''.join(X1)
    s = len(X1)  # 总长度
    z = X1.find(".")  # 整数长度
    d = s - z - 1  # 小数长度
    if d == 0:
        X1 = X1 + "0000"
    elif d == 1:
        X1 = X1 + "000"
    elif d == 2:
        X1 = X1 + "00"
    elif d == 2:
        X1 = X1 + "0"
    if z == 0:
        X1 = "0000" + X1
    if z == 1:
        X1 = "000" + X1
    if z == 2:
        X1 = "00" + X1
    if z == 3:
        X1 = "0" + X1
    X = list(X1)
    return X

def dTob(n, pre=4):
    '''
    把十进制的浮点数n转换成二进制
    小数点后面保留pre位小数
    '''
    string_number1 = str(n)  # number1 表示十进制数，number2表示二进制数
    flag = False
    for i in string_number1:  # 判断是否含小数部分
        if i == '.':
            flag = True
            break
    if flag:
        string_integer, string_decimal = string_number1.split('.')  # 分离整数部分和小数部分
        integer = int(string_integer)
        decimal = Decimal(str(n)) - integer
        l1 = [0, 1]
        l2 = []
        decimal_convert = ""
        while True:
            if integer == 0: break
            x, y = divmod(integer, 2)  # x为商，y为余数
            l2.append(y)
            integer = x
        string_integer = ''.join([str(j) for j in l2[::-1]])  # 整数部分转换成二进制
        i = 0
        while decimal != 0 and i < pre:
            result = int(decimal * 2)
            decimal = decimal * 2 - result
            decimal_convert = decimal_convert + str(result)
            i = i + 1
        string_number2 = string_integer + '.' + decimal_convert
        return float(string_number2)


    else:  # 若十进制只有整数部分
        l1 = [0, 1]
        l2 = []
        while True:
            if n == 0: break
            x, y = divmod(n, 2)  # x为商，y为余数
            l2.append(y)
            n = x
        string_number = ''.join([str(j) for j in l2[::-1]])
        return int(string_number)

# bin code
def two2ten(number):
    for X in number:
        sum = 0.0
        for i in range(len(X)):
            X[i] = bTod(X[i],4)

# dec code:
def ten2two(number):
    # 定义栈
    for i in number:
        for j in range(len(i)):
            # i[j]
            if i[j]!=0.0:
                i[j] = str(dTob(float(i[j])))
            else:
                i[j] = "0"+"."+"0"
            s = len(i[j])  # 总长度
            z = i[j].find(".")  # 整数长度
            d = s - z - 1  # 小数长度
            if d==0:
                i[j]=i[j]+"0000"
            elif d==1:
                i[j] = i[j] + "000"
            elif d==2:
                i[j] = i[j] + "00"
            elif d==2:
                i[j] = i[j] + "0"
            if z==0:
                i[j] = "0000"+i[j]
            elif z==1:
                i[j] = "000"+i[j]
            elif z==2:
                i[j] = "00"+i[j]
            elif z==3:
                i[j] = "0"+i[j]

# minimize  dec
def obj(A, X):
    x, y, z, m, n, p = X
    a, b, c, d, e = A
    return float((a * x + b * y + c * z + e / (1 + math.exp(d/10 * m))) * (n / (m + 0.001))-p )

# dec vec return dec
def select(X1, X2, X3, X4, X5, X6, A):
    v1 = obj(X1, A)
    v2 = obj(X2, A)
    v3 = obj(X3, A)
    v4 = obj(X4, A)
    v5 = obj(X5, A)
    v6 = obj(X6, A)
    sum = v1 + v2 + v3 + v4 + v5 + v6
    if sum == 0.0:
        sum = sum+1
    if v1 == 0.0:
        v1 = v1 + 1
    if v2 == 0.0:
        v2 = v2 + 1
    if v3 == 0.0:
        v3 = v3+1
    if v4 == 0.0:
        v4 = v4+1
    if v5 == 0.0:
        v5 = v5+1
    if v6 == 0.0:
        v6 = v6+1
    s1 = v1 / sum
    s2 = v2 / sum
    s3 = v3 / sum
    s4 = v4 / sum
    s5 = v5 / sum
    s6 = v6 / sum
    next1 = random.choices([X1, X2, X3, X4, X5, X6], weights=[s1, s2, s3, s4, s5, s6], k=5)
    max1 = max(v1, v2, v3, v4, v5, v6)
    if max1 == v1:
        next1.append(X1)
    elif max1 == v2:
        next1.append(X2)
    elif max1 == v3:
        next1.append(X3)
    elif max1 == v4:
        next1.append(X4)
    elif max1 == v5:
        next1.append(X5)
    elif max1 == v6:
        next1.append(X6)
    return next1.copy()


# input  two binary vectors
def cross(X1, X2, rate=0.6):
    X1 = exam(X1)
    X2 = exam(X2)
    for i in range(8):
        if random.uniform(0, 1) < rate:
            a = random.choices([0, 1, 2, 3, 4, 5, 6, 7], k=2)
            temp1 = 0
            for i in range(len(a)):
                temp1 = int(float(X1[i]))
                X1[i] = str(X2[i])
                X2[i] = str(temp1)

# bin
def mutation(X, rate=0.7):
    if random.uniform(0, 1) < rate:
        temp = random.randint(0,4)
        a = random.choices([0, 1, 2, 3, 4, 5, 6, 7], k=1)
        X[temp] = exam(X[temp])
        t = list(X[temp])
        if t[a[0]] == "." :
            a[0] = a[0] + 1
        t[a[0]] = str(1 - int(float(t[a[0]])))
        X[temp] = ''.join(t)

data = pd.read_excel(r'C:\Users\glone\Desktop\datachange3.xlsx')
data = pd.DataFrame(data)
X = []
for i in range(len(data)):
    X.append(data.iloc[i, 2:])
X = np.array(X)
y = data.iloc[:, 1]
y = np.array(y)
# initialization
optimal = [[[7.0, 4.0, 7.0, 0.2, 3.0]], [[3.0, 5.0, 3.0, 0.2, 5.0]], [[1.0, 1.0, 1.0, 1.2, 1.0]]]

for j in optimal:
    sumtemp = 0
    for p in range(len(X)):
        value = obj(j[0], (X[p][0], X[p][1], X[p][2], X[p][3], X[p][4], y[p]))
        sumtemp = sumtemp + (y[p] - value) ** 2
    j.append(sumtemp / len(X))
print("ready")
op = [[10.0, 2.0, 3.0, 0.1, 10.0], [3.0, 5.0, 3.0, 0.2, 5.0], [3.0, 6.0, 2.0, 0.1, 7.0], [7.0, 4.0, 7.0, 0.2, 3.0], [1.0,1.0, 1.0, 0.3, 1.0],
      [10.0, 5.0, 2.0, 2,6.0]]
count = 1000
for qwe in range(count):
    for i in range(len(X)):
        # 需要十进制
        xhere = X[i]  # [1,2,3,4,5 ]
        yhere = y[i]  # num
        t = select(op[0], op[1], op[2], op[3], op[4], op[5], (xhere[0], xhere[1], xhere[2], xhere[3], xhere[4], yhere))
        # 十进制转二进制
        ten2two(op)
        a = random.choices([0, 1, 2, 3, 4, 5], k=2)
        cross(op[a[0]], op[a[1]])
        a = random.choices([0, 1, 2, 3, 4, 5], k=1)
        mutation(op[a[0]])
        two2ten(op)
        for wuri in op:
            for yy in range(len(wuri)):
                if wuri[yy]>20:
                    wuri[yy]=20
    op2 = op.copy()
    for p in op2:
        for pp in p:
            pp = pp*0.9
    for j in op:
        sumtemp = 0

        for p in range(len(X)):
            value = obj(j, (X[p][0],X[p][1],X[p][2],X[p][3],X[p][4],y[p]))
            sumtemp = sumtemp + (y[p] - value) ** 2
        max2 = max(optimal[0][1], optimal[1][1], optimal[2][1])
        if sumtemp/len(X) < max2:
            if optimal[0][1] == max2:
                optimal[0][0] = j
                optimal[0][1] = sumtemp/len(X)
            elif optimal[1][1] == max2:
                optimal[1][0] = j
                optimal[1][1] = sumtemp/len(X)
            elif optimal[1][1] == max2:
                optimal[2][0] = j
                optimal[2][1] = sumtemp/len(X)
        print(j, sumtemp/len(X))
for wer in optimal:
    print(optimal[0], optimal[1])

for j in op2:
        sumtemp = 0
        for p in range(len(X)):
            value = obj(j, (X[p][0],X[p][1],X[p][2],X[p][3],X[p][4],y[p]))
            sumtemp = sumtemp + (y[p] - value) ** 2
        max2 = max(optimal[0][1], optimal[1][1], optimal[2][1])
        if sumtemp/len(X) < max2:
            if optimal[0][1] == max2:
                optimal[0][0] = j
                optimal[0][1] = sumtemp/len(X)
            elif optimal[1][1] == max2:
                optimal[1][0] = j
                optimal[1][1] = sumtemp/len(X)
            elif optimal[1][1] == max2:
                optimal[2][0] = j
                optimal[2][1] = sumtemp/len(X)
        print(j, sumtemp/len(X))
for wer in optimal:
    print(optimal[0], optimal[1])
op3 = op.copy()
for p in op3:
    for pp in p:
        pp = pp*0.8
for j in op:
    sumtemp = 0

for j in op3:
        sumtemp = 0
        for p in range(len(X)):
            value = obj(j, (X[p][0],X[p][1],X[p][2],X[p][3],X[p][4],y[p]))
            sumtemp = sumtemp + (y[p] - value) ** 2
        max2 = max(optimal[0][1], optimal[1][1], optimal[2][1])
        print(j, sumtemp / len(X))
        if sumtemp/len(X) < max2:
            if optimal[0][1] == max2:
                optimal[0][0] = j
                optimal[0][1] = sumtemp/len(X)
            elif optimal[1][1] == max2:
                optimal[1][0] = j
                optimal[1][1] = sumtemp/len(X)
            elif optimal[1][1] == max2:
                optimal[2][0] = j
                optimal[2][1] = sumtemp/len(X)
for wer in optimal:
    print(optimal[0], optimal[1])
