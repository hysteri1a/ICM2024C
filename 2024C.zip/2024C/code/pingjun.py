# -*- coding: utf-8 -*-
import numpy as np
import geatpy as ea

"""
    max f1 = x1 * x2 + x3
    min f2 = x1 + x2 - x3
    s.t.
    2*x1 + x2 - 1 <= 0
    x1 + 2*x3 - 2 <= 0
    x1 + x2 + x3 - 1 == 0

    1 <= x1  <= 4
    -10 <= x2 <= 1
    0 < x3 < 2
"""


class MyProblem(ea.Problem):  # 继承Problem父类
    def __init__(self):
        name = "MyProblem"
        M = 2  # f的数量
        maxormins = [-1, 1]  # (目标最小最大化标记列表，1：最小化该目标；-1：最大化该目标）
        Dim = 4  # x的个数

        # x的上下界与定义边界是开区间还是闭区间
        var_types = [0] * Dim  # 元素为0表示对应的变量是连续的；1表示是离散的
        lb = [0, 0, 0,0]  # 决策变量下界
        ub = [1, 1, 1,1]  # 决策变量上界
        lbin = [1, 1, 1, 1]  # 决策变量下边界（0表示不包含该变量的下边界，1表示包含）
        ubin = [1, 1, 1, 1]  # 决策变量上边界（0表示不包含该变量的上边界，1表示包含）
        ea.Problem.__init__(self, name, M, maxormins, Dim, var_types, lb, ub, lbin, ubin)

    def aimFunc(self, pop, X):  # 目标函数
        Vars = pop.Phen  # 得到决策变量矩阵
        a1 = X[0]
        a2 = X[1]
        a3 = X[2]
        a4 = X[3]
        x1 = Vars[:, [0]]
        x2 = Vars[:, [1]]
        x3 = Vars[:, [2]]
        x4 = Vars[:, [3]]
        # 目标函数:
        f1 = x1 * x2 + x3
        f2 = x1 + x2 - x3
        pop.ObjV = np.hstack([f1, f2])
        # 约束条件:(要全部化为 <= )
        c1 = 2 * x1 + x2 - 1
        c2 = x1 + 2 * x3 - 2  # 约束条件 <= 0
        c3 = np.abs(x1 + x2 + x3 - 1)  # 约束条件 = 0
        pop.CV = np.hstack([c1, c2, c3])