from sklearn import datasets
from sklearn.model_selection import train_test_split
from slsdt.slsdt import SLSDT
import pandas as pd
import openpyxl
import numpy as np

data = pd.read_excel(r'C:\Users\钱天豪\Desktop\forstrydata.xlsx')
data = pd.DataFrame(data)
X =[]
for i in range(len(data)):
    X.append(data.iloc[i,1:])
X = np.array(X)
y = data.iloc[:,0]
y = np.array(y)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
print(X,y)
clf = SLSDT()
clf.fit(X_train, y_train)
clf.print_tree()

result = clf.predict(X_test)

print(result)
print(sum((result == y_test))/len(result))

from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt

fpr, tpr, thersholds = roc_curve(y_test, result)

for i, value in enumerate(thersholds):
    print("%f %f %f" % (fpr[i], tpr[i], value))

roc_auc = auc(fpr, tpr)

plt.plot(fpr, tpr, 'k--', label='ROC (area = {0:.2f})'.format(roc_auc), lw=2)

plt.xlim([-0.05, 1.05])  # 设置x、y轴的上下限，以免和边缘重合，更好的观察图像的整体
plt.ylim([-0.05, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')  # 可以使用中文，但需要导入一些库即字体
plt.title('ROC Curve')
plt.legend(loc="lower right")
plt.show()
