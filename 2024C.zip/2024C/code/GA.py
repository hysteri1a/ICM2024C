import math

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import pandas as pd
import openpyxl

data = pd.read_excel(r'C:\Users\钱天豪\Desktop\datachange3.xlsx')
data = pd.DataFrame(data)
X1 = np.array(data.iloc[:, 2])
X2 = np.array(data.iloc[:, 3])
X3 = np.array(data.iloc[:, 4])
X4 = np.array(data.iloc[:, 5])
X5 = np.array(data.iloc[:, 6])
y = data.iloc[:, 1]
y = np.array(y)


def exp(X, d):
    return [1 / math.exp(d * i) for i in X]


def func(X, a, b, c, d):
    x, t, z, m, n = X
    return (-1) * (a * x + b * t + c * z + exp(m, d) * (n / m))


# 使用curve_fit函数来拟合非线性数据
popt = curve_fit(func, (X1, X2, X3, X4, X5), y, maxfev=100000000)
print(popt)


def cal(X, A):
    x, t, z, m, n = X
    a, b, c, d = A
    return (-1) * (a * x + b * t + c * z + exp(m, d) * (n / m))


ypred = [cal((X1, X2, X3, X4, X5), popt)]
from sklearn.metrics import mean_squared_error  # 均方误差
from sklearn.metrics import mean_absolute_error  # 平方绝对误差
from sklearn.metrics import r2_score  # R square


# 调整后的R square
def adj_r_squared(x_test, y_test, y_predict):
    SS_R = sum((y_test - y_predict) ** 2)
    SS_T = sum((y_test - np.mean(y_test)) ** 2)
    r_squared = 1 - (float(SS_R)) / SS_T
    adj_r_squared = 1 - (1 - r_squared) * (len(y_test) - 1) / (len(y_test) - x_test.shape[1] - 1)
    return adj_r_squared


# 皮尔逊相关系数
from scipy.stats import pearsonr

# 调用
mean_squared_error(y, ypred)
mean_absolute_error(y, ypred)
r2_score(y, ypred)
