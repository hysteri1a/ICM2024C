from datetime import *
import math

import matplotlib.pyplot as plt  # 画图用
import numpy as np
import pandas as pd
import matplotlib
import openpyxl
data = pd.read_excel(r'C:\Users\钱天豪\Desktop\roc.xlsx')
df = pd.DataFrame(data)

t1 = list(df.loc[:, "mm1"])
t2 = list(df.loc[:, "Grade1"])
t3 = list(df.loc[:, "Grade2"])
X = []
Y = []

for i in range(len(t2)):
    if t2[i]*t3[i]<=0:
        continue
    elif t2[i]>0:
        temp = t2[i]
        t2[i]=t2[i]/(t2[i]+t3[i])
        t3[i]= t3[i]/(temp+t3[i])
        print(t2[i],t3[i])
    elif t2[i]<0:
        temp = t2[i]
        t2[i]= t3[i]/(t2[i]+t3[i])
        t3[i]= temp/(temp+t3[i])
        print(t2[i], t3[i])
    X.append([t2[i],t3[i]])
    Y.append(t1[i])
print(X)
print(Y)

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_curve, auc
import sklearn.linear_model as lm
l2 = lm.LogisticRegression(C=50)
result = l2.fit(X, Y)
resu = result.predict(X)
print(sum(resu==Y)/len(Y))
print(l2.score(X,Y))

from sklearn.metrics import roc_curve
# 计算ROC，并绘制曲线
fpr, tpr, thresholds = roc_curve(resu, np.array(Y), pos_label=2)
plt.plot(fpr, tpr)
plt.xlabel("FPR")
plt.ylabel("TPR")
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.show()
# 查看其对应模型的w（各项的系数）
print('the weight of Logistic Regression:',l2.coef_)
# 查看其对应模型的w0(截距)
print('the intercept(w0) of Logistic Regression:',l2.intercept_)

# the weight of Logistic Regression: [[0.73455784 0.69539712]]
# the intercept(w0) of Logistic Regression: [-0.13139986]




